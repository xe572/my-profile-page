import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import EducationSection from '@/components/EducationSection';
import InternshipSection from '@/components/InternshipSection';
import SkillsSection from '@/components/SkillsSection';
import ProjectsSection from '@/components/ProjectsSection';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <HeroSection />
        <EducationSection />
        <InternshipSection />
        <SkillsSection />
        <ProjectsSection />
      </main>
      
      {/* 页脚 */}
      <footer className="py-8 px-4 border-t border-border bg-card/50">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-muted-foreground mb-2">
            © 2025 Xinia. 保留所有权利.
          </p>
          <p className="text-sm text-muted-foreground">
            使用 React + TypeScript + Tailwind CSS 构建
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
