import { Code, Database, Brain, BarChart3, Languages, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const SkillsSection = () => {
  const skillCategories = [
    {
      icon: Code,
      title: '编程技能',
      skills: [
        { name: 'Python', level: 90 },
        { name: 'R语言', level: 75 },
        { name: 'SQL', level: 85 },
        { name: 'JavaScript', level: 70 },
      ],
    },
    {
      icon: Brain,
      title: '人工智能',
      skills: [
        { name: '机器学习', level: 85 },
        { name: '深度学习', level: 75 },
        { name: '自然语言处理', level: 70 },
        { name: '数据挖掘', level: 80 },
      ],
    },
    {
      icon: BarChart3,
      title: '数据分析',
      skills: [
        { name: '数据可视化', level: 88 },
        { name: '统计分析', level: 85 },
        { name: 'Tableau', level: 80 },
        { name: 'Excel高级应用', level: 90 },
      ],
    },
    {
      icon: Database,
      title: '工具框架',
      skills: [
        { name: 'TensorFlow', level: 75 },
        { name: 'PyTorch', level: 70 },
        { name: 'Pandas', level: 88 },
        { name: 'NumPy', level: 85 },
      ],
    },
  ];

  const softSkills = [
    {
      icon: Users,
      title: '团队协作',
      description: '具备良好的团队合作精神，能够高效沟通协作',
    },
    {
      icon: Languages,
      title: '语言能力',
      description: '英语CET-6，能够阅读英文文献和技术文档',
    },
    {
      icon: Brain,
      title: '学习能力',
      description: '快速学习新技术，保持对新知识的好奇心',
    },
  ];

  return (
    <section id="skills" className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="gradient-text">个人技能</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            我的专业技能与核心竞争力
          </p>
        </div>

        {/* 专业技能 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {skillCategories.map((category, index) => (
            <Card key={index} className="card-glow">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <category.icon className="h-6 w-6 text-primary" />
                  </div>
                  <span>{category.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {category.skills.map((skill, idx) => (
                    <div key={idx}>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium text-foreground">{skill.name}</span>
                        <span className="text-sm text-muted-foreground">{skill.level}%</span>
                      </div>
                      <div className="skill-progress">
                        <div
                          className="skill-progress-bar"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* 软技能 */}
        <div>
          <h3 className="text-2xl font-bold text-center mb-8">
            <span className="gradient-text">通用技能</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {softSkills.map((skill, index) => (
              <Card key={index} className="card-glow text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    <div className="p-4 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full">
                      <skill.icon className="h-8 w-8 text-primary" />
                    </div>
                  </div>
                  <h4 className="text-lg font-semibold mb-2">{skill.title}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {skill.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* 技能总结 */}
        <Card className="mt-12 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">持续学习</h3>
              <p className="text-muted-foreground leading-relaxed max-w-3xl mx-auto">
                技术日新月异，我始终保持学习的热情。通过在线课程、技术书籍和实践项目，
                不断提升自己的专业能力，努力成为智能经济领域的专业人才。
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default SkillsSection;
