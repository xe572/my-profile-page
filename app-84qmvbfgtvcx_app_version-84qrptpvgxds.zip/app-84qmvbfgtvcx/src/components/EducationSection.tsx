import { GraduationCap, Award, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const EducationSection = () => {
  const educationData = [
    {
      period: '2020 - 2024',
      school: '武汉理工大学',
      major: '智能经济',
      degree: '本科',
      description: '系统学习经济学理论与人工智能技术的交叉学科，掌握数据分析、机器学习等核心技能。',
      achievements: [
        '连续三年获得学业奖学金',
        '参与多项科研项目，发表学术论文',
        '担任学生会干部，组织多场学术活动',
      ],
    },
  ];

  const highlights = [
    {
      icon: GraduationCap,
      title: '专业排名',
      value: 'Top 10%',
      description: '专业成绩优异',
    },
    {
      icon: Award,
      title: '获奖经历',
      value: '5+',
      description: '各类奖学金与荣誉',
    },
    {
      icon: TrendingUp,
      title: '项目经验',
      value: '8+',
      description: '课程项目与实践',
    },
  ];

  return (
    <section id="education" className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="gradient-text">教育经历</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            我的学业成长轨迹
          </p>
        </div>

        {/* 亮点数据 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {highlights.map((item, index) => (
            <Card key={index} className="card-glow text-center">
              <CardContent className="pt-6">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-primary/10 rounded-full">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">{item.title}</h3>
                <p className="text-3xl font-bold gradient-text mb-2">{item.value}</p>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* 教育详情 */}
        <div className="space-y-8">
          {educationData.map((edu, index) => (
            <Card key={index} className="card-glow">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <CardTitle className="text-2xl mb-2">{edu.school}</CardTitle>
                    <div className="flex flex-wrap gap-3 text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <GraduationCap className="h-4 w-4" />
                        {edu.major}
                      </span>
                      <span>·</span>
                      <span>{edu.degree}</span>
                    </div>
                  </div>
                  <div className="px-4 py-2 bg-primary/10 rounded-lg">
                    <span className="text-primary font-semibold">{edu.period}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {edu.description}
                </p>
                
                <div>
                  <h4 className="font-semibold mb-3 text-foreground">主要成就</h4>
                  <div className="space-y-2">
                    {edu.achievements.map((achievement, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <div className="mt-1.5 h-2 w-2 rounded-full bg-primary flex-shrink-0"></div>
                        <p className="text-muted-foreground">{achievement}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
