import { Mail, MapPin, Heart, Book, Camera } from 'lucide-react';
import { Card } from '@/components/ui/card';

const HeroSection = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 pt-16">
      <div className="max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* 左侧内容 */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              <span className="text-foreground">你好，我是</span>
              <br />
              <span className="gradient-text">Xinia</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-6 max-w-2xl">
              武汉理工大学 · 智能经济专业
            </p>

            <p className="text-lg text-muted-foreground mb-8 max-w-2xl leading-relaxed">
              一名充满热情的智能经济专业学生，致力于探索人工智能与经济学的交叉领域。
              我相信技术可以改变世界，也期待用数据和智能为社会创造价值。
            </p>

            {/* 个人信息 */}
            <Card className="p-6 bg-card/50 backdrop-blur-sm border-border">
              <div className="space-y-3 text-left">
                <div className="flex items-center gap-3 text-muted-foreground">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>武汉理工大学</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Mail className="h-5 w-5 text-primary" />
                  <span>xinia@example.com</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Heart className="h-5 w-5 text-primary" />
                  <span>开朗乐观 · 善于学习</span>
                </div>
              </div>
            </Card>

            {/* 兴趣爱好 */}
            <div className="mt-8">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4">兴趣爱好</h3>
              <div className="flex flex-wrap gap-3 justify-center lg:justify-start">
                <div className="flex items-center gap-2 px-4 py-2 bg-secondary rounded-full">
                  <Book className="h-4 w-4 text-primary" />
                  <span className="text-sm">阅读</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-secondary rounded-full">
                  <Camera className="h-4 w-4 text-primary" />
                  <span className="text-sm">摄影</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-secondary rounded-full">
                  <span className="text-lg">🎵</span>
                  <span className="text-sm">音乐</span>
                </div>
              </div>
            </div>
          </div>

          {/* 右侧图片 */}
          <div className="relative">
            <div className="relative w-full max-w-lg mx-auto">
              <div className="absolute inset-0 gradient-bg rounded-full blur-3xl opacity-20"></div>
              <img
                src="https://miaoda-site-img.cdn.bcebos.com/images/6e332f02-7763-4a03-b63d-b1df4e18c09d.jpg"
                alt="Xinia个人照片"
                className="relative z-10 w-full h-auto rounded-2xl card-glow"
              />
              
              {/* 浮动元素 */}
              <div className="absolute -top-4 -right-4 bg-card p-4 rounded-lg card-glow">
                <div className="text-center">
                  <div className="text-2xl font-bold gradient-text">22</div>
                  <div className="text-xs text-muted-foreground">岁</div>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-card p-4 rounded-lg card-glow">
                <div className="text-center">
                  <div className="text-lg font-bold gradient-text">本科</div>
                  <div className="text-xs text-muted-foreground">学历</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
