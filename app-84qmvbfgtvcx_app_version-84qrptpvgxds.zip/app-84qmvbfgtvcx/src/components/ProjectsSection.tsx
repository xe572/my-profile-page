import { ExternalLink, Github } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const ProjectsSection = () => {
  const projects = [
    {
      title: '智能经济数据分析平台',
      description: '基于机器学习的经济数据分析与预测系统，能够对宏观经济指标进行智能分析和趋势预测。',
      image: 'https://miaoda-site-img.cdn.bcebos.com/images/7fb15045-c1e4-47e0-8b0f-303a74211701.jpg',
      tags: ['Python', '机器学习', '数据分析', 'Flask'],
      highlights: [
        '集成多个经济数据源，实现数据自动采集',
        '运用LSTM模型进行时间序列预测',
        '构建交互式数据可视化仪表板',
      ],
    },
    {
      title: '商业智能BI系统',
      description: '为企业提供数据驱动决策支持的商业智能系统，包含数据可视化、报表生成等功能。',
      image: 'https://miaoda-image.cdn.bcebos.com/img/corpus/366848d01da64b8bac588e2205d94943.jpg',
      tags: ['数据可视化', 'Tableau', 'SQL', 'ETL'],
      highlights: [
        '设计并实现ETL数据处理流程',
        '创建20+交互式数据看板',
        '帮助企业提升决策效率30%',
      ],
    },
    {
      title: 'AI驱动的投资组合优化',
      description: '运用深度学习技术优化投资组合配置，实现风险与收益的平衡。',
      image: 'https://miaoda-site-img.cdn.bcebos.com/images/ce28c6b1-6c76-4003-855a-6f2c51a6f25d.jpg',
      tags: ['深度学习', 'TensorFlow', '金融分析', 'Python'],
      highlights: [
        '构建基于强化学习的投资策略模型',
        '回测收益率超越基准指数15%',
        '实现风险控制与收益优化',
      ],
    },
    {
      title: '团队协作数据分析项目',
      description: '与团队合作完成的大型数据分析项目，涉及市场研究、用户行为分析等多个维度。',
      image: 'https://miaoda-site-img.cdn.bcebos.com/images/886dcea0-b660-4236-8ccb-8b18255b6b9b.jpg',
      tags: ['团队协作', 'Python', 'R语言', '数据挖掘'],
      highlights: [
        '协调5人团队完成项目交付',
        '处理并分析超过500万条数据',
        '项目成果获得导师高度评价',
      ],
    },
  ];

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="gradient-text">作品展示</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            我的项目经历与实践成果
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="card-glow overflow-hidden group">
              {/* 项目图片 */}
              <div className="relative h-64 overflow-hidden bg-muted">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <CardHeader>
                <CardTitle className="text-xl mb-2">{project.title}</CardTitle>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
              </CardHeader>

              <CardContent>
                {/* 项目亮点 */}
                <div className="mb-4">
                  <h4 className="text-sm font-semibold mb-3 text-foreground">项目亮点</h4>
                  <div className="space-y-2">
                    {project.highlights.map((highlight, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <div className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary flex-shrink-0"></div>
                        <p className="text-sm text-muted-foreground">{highlight}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 技术标签 */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                {/* 操作按钮 */}
                <div className="flex gap-3">
                  <Button variant="outline" size="sm" className="flex-1">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    查看详情
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Github className="h-4 w-4 mr-2" />
                    源码
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* 更多项目提示 */}
        <Card className="mt-12 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">持续创造</h3>
              <p className="text-muted-foreground leading-relaxed max-w-3xl mx-auto mb-6">
                以上只是我部分代表性项目。我热衷于将理论知识转化为实际应用，
                通过项目实践不断提升自己的技术能力和问题解决能力。
              </p>
              <Button className="gradient-bg">
                <ExternalLink className="h-4 w-4 mr-2" />
                查看更多项目
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default ProjectsSection;
