import { Briefcase, Calendar, MapPin, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const InternshipSection = () => {
  const internships = [
    {
      company: '某科技公司',
      position: '数据分析实习生',
      location: '武汉',
      period: '2023.06 - 2023.09',
      description: '负责用户行为数据分析，协助产品优化决策，参与多个数据驱动的项目。',
      responsibilities: [
        '使用Python进行数据清洗和分析，处理超过100万条用户数据',
        '构建数据可视化仪表板，为产品团队提供决策支持',
        '参与A/B测试设计与结果分析，提升用户转化率15%',
        '协助撰写数据分析报告，向管理层汇报项目进展',
      ],
      skills: ['Python', 'SQL', 'Tableau', '数据分析'],
    },
    {
      company: '某金融机构',
      position: '金融科技实习生',
      location: '上海',
      period: '2023.12 - 2024.03',
      description: '参与智能投顾系统开发，运用机器学习技术优化投资策略。',
      responsibilities: [
        '研究并实现基于机器学习的股票预测模型',
        '分析金融市场数据，识别投资机会和风险',
        '协助开发智能投顾算法，提升投资组合收益',
        '参与团队技术分享，学习金融科技前沿技术',
      ],
      skills: ['机器学习', 'Python', '金融分析', 'TensorFlow'],
    },
  ];

  return (
    <section id="internship" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            <span className="gradient-text">实习经历</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            在实践中成长，在工作中学习
          </p>
        </div>

        <div className="space-y-8">
          {internships.map((internship, index) => (
            <Card key={index} className="card-glow">
              <CardHeader>
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-3">{internship.position}</CardTitle>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Briefcase className="h-4 w-4 text-primary" />
                        <span className="font-medium">{internship.company}</span>
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>{internship.period}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          <span>{internship.location}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* 技能标签 */}
                  <div className="flex flex-wrap gap-2">
                    {internship.skills.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {internship.description}
                </p>
                
                <div>
                  <h4 className="font-semibold mb-4 text-foreground flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-primary" />
                    主要职责与成果
                  </h4>
                  <div className="space-y-3">
                    {internship.responsibilities.map((responsibility, idx) => (
                      <div key={idx} className="flex items-start gap-3 timeline-item">
                        <div className="timeline-node"></div>
                        <p className="text-muted-foreground leading-relaxed">{responsibility}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* 实习总结 */}
        <Card className="mt-8 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-3">实习收获</h3>
              <p className="text-muted-foreground leading-relaxed max-w-3xl mx-auto">
                通过实习经历，我不仅提升了专业技能，更学会了如何在团队中协作、如何将理论知识应用于实践。
                这些宝贵的经验让我对智能经济领域有了更深入的理解，也更加坚定了我的职业目标。
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default InternshipSection;
