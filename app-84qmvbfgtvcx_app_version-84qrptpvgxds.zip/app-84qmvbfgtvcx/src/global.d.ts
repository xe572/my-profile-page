// global types
